// ===== app.js : shared code for ALL pages (navbar, audio player, likes, playlists) =====

// ---------- Small helper functions ----------
function load(key, fallback) {                 // read from localStorage
  try {
    var v = JSON.parse(localStorage.getItem(key));
    return v === null ? fallback : v;
  } catch (e) { return fallback; }
}
function save(key, value) {                    // write to localStorage
  localStorage.setItem(key, JSON.stringify(value));
}
function getSong(id) {
  return SONGS.filter(function (s) { return s.id === id; })[0];
}
function esc(text) {                           // makes user text safe to show in HTML
  var d = document.createElement("div");
  d.textContent = text;
  return d.innerHTML;
}
function fmt(sec) {                            // 75 -> "1:15"
  if (isNaN(sec)) return "0:00";
  var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
  return m + ":" + (s < 10 ? "0" : "") + s;
}

// ---------- Saved data ----------
var audio = new Audio();                       // the HTML5 audio object
var currentId = load("currentId", SONGS[0].id);
var likes = load("likes", []);                 // list of liked song ids
var playlists = load("playlists", []);         // [{name:"Gym", songs:[1,2]}]
var user = load("user", null);                 // logged in user name
var resumeTime = load("time", 0);              // where the song stopped last time

// ---------- Build the navigation bar ----------
function buildNav() {
  var page = location.pathname.split("/").pop() || "index.html";
  var links = [
    ["index.html", "Home"], ["browse.html", "Browse"], ["album.html", "Albums"],
    ["nowplaying.html", "Now Playing"], ["playlists.html", "My Playlists"], ["search.html", "Search"]
  ];
  var html = '<a class="logo" href="index.html">🎵 Musify</a>' +
             '<button id="menuBtn">☰</button><nav id="menu">';
  links.forEach(function (l) {
    html += '<a href="' + l[0] + '"' + (l[0] === page ? ' class="active"' : '') + '>' + l[1] + '</a>';
  });
  html += user ? '<a href="#" id="logout">Logout (' + esc(user) + ')</a>'
               : '<a href="login.html"' + (page === "login.html" ? ' class="active"' : '') + '>Login</a>';
  html += '</nav>';
  document.getElementById("nav").innerHTML = html;

  document.getElementById("menuBtn").onclick = function () {
    document.getElementById("menu").classList.toggle("open");
  };
  var lo = document.getElementById("logout");
  if (lo) lo.onclick = function (e) {
    e.preventDefault();
    localStorage.removeItem("user");
    location.href = "login.html";
  };
}

// ---------- Build the bottom player bar ----------
function buildPlayer() {
  document.getElementById("player").innerHTML =
    '<div class="now">' +
      '<div class="cover" id="pCover"></div>' +
      '<div class="info"><b id="pTitle"></b><small id="pArtist"></small></div>' +
    '</div>' +
    '<div class="controls">' +
      '<button id="prevBtn" title="Previous">⏮</button>' +
      '<button id="playBtn" title="Play / Pause">▶</button>' +
      '<button id="nextBtn" title="Next">⏭</button>' +
      '<button id="pLike" title="Like">♡</button>' +
    '</div>' +
    '<div class="seekbox">' +
      '<small id="curTime">0:00</small>' +
      '<input type="range" id="seek" min="0" max="100" value="0">' +
      '<small id="durTime">0:00</small>' +
    '</div>' +
    '<div class="eq"><span></span><span></span><span></span><span></span><span></span></div>' +
    '<div>🔊 <input type="range" class="vol" id="vol" min="0" max="1" step="0.01" value="0.8"></div>';

  // buttons
  document.getElementById("playBtn").onclick = togglePlay;
  document.getElementById("nextBtn").onclick = nextSong;
  document.getElementById("prevBtn").onclick = prevSong;
  document.getElementById("pLike").onclick = function () { toggleLike(currentId); };

  // seek bar: user drags -> change the song position
  document.getElementById("seek").oninput = function () {
    if (audio.duration) audio.currentTime = (this.value / 100) * audio.duration;
  };
  // volume
  var vol = load("volume", 0.8);
  audio.volume = vol;
  document.getElementById("vol").value = vol;
  document.getElementById("vol").oninput = function () {
    audio.volume = this.value;
    save("volume", Number(this.value));
  };
}

// ---------- Audio events ----------
audio.addEventListener("timeupdate", function () {
  if (audio.duration) {
    document.getElementById("seek").value = (audio.currentTime / audio.duration) * 100;
  }
  document.getElementById("curTime").textContent = fmt(audio.currentTime);
  save("time", audio.currentTime);
});
audio.addEventListener("loadedmetadata", function () {
  document.getElementById("durTime").textContent = fmt(audio.duration);
  if (resumeTime > 0) {                         // continue from the saved position
    audio.currentTime = resumeTime;
    resumeTime = 0;
  }
});
audio.addEventListener("play", function () {
  document.body.classList.add("playing");
  document.getElementById("playBtn").textContent = "⏸";
});
audio.addEventListener("pause", function () {
  document.body.classList.remove("playing");
  document.getElementById("playBtn").textContent = "▶";
});
audio.addEventListener("ended", nextSong);      // auto-play next song

// ---------- Player functions ----------
function loadSong(id, autoplay) {
  var s = getSong(id);
  currentId = id;
  save("currentId", id);
  audio.src = s.file;
  document.getElementById("pCover").textContent = s.emoji;
  document.getElementById("pCover").style.background = s.color;
  document.getElementById("pTitle").textContent = s.title;
  document.getElementById("pArtist").textContent = s.artist;
  refreshLikes();
  if (autoplay) audio.play();
  window.dispatchEvent(new Event("songchange"));  // pages (like Now Playing) listen to this
}
function togglePlay() {
  if (audio.paused) audio.play(); else audio.pause();
}
function nextSong() {
  var i = SONGS.indexOf(getSong(currentId));
  loadSong(SONGS[(i + 1) % SONGS.length].id, true);
}
function prevSong() {
  var i = SONGS.indexOf(getSong(currentId));
  loadSong(SONGS[(i - 1 + SONGS.length) % SONGS.length].id, true);
}

// ---------- Likes ----------
function toggleLike(id) {
  var pos = likes.indexOf(id);
  if (pos === -1) likes.push(id); else likes.splice(pos, 1);
  save("likes", likes);
  refreshLikes();
  window.dispatchEvent(new Event("likechange"));
}
function refreshLikes() {                       // update every heart button on the page
  var hearts = document.querySelectorAll("[data-like]");
  for (var i = 0; i < hearts.length; i++) {
    var liked = likes.indexOf(Number(hearts[i].getAttribute("data-like"))) !== -1;
    hearts[i].textContent = liked ? "♥" : "♡";
    hearts[i].classList.toggle("liked", liked);
  }
  var pl = document.getElementById("pLike");
  var isLiked = likes.indexOf(currentId) !== -1;
  pl.textContent = isLiked ? "♥" : "♡";
  pl.classList.toggle("liked", isLiked);
}

// ---------- Song row (used on many pages) ----------
function songRow(s, extraButton) {
  var liked = likes.indexOf(s.id) !== -1;
  return '<div class="row">' +
    '<div class="cover" style="background:' + s.color + '">' + s.emoji + '</div>' +
    '<div class="info"><b>' + s.title + '</b><small>' + s.artist + ' • ' + s.album + '</small></div>' +
    '<button data-play="' + s.id + '" title="Play">▶</button>' +
    '<button data-like="' + s.id + '" class="' + (liked ? "liked" : "") + '" title="Like">' + (liked ? "♥" : "♡") + '</button>' +
    '<button data-add="' + s.id + '" class="small" title="Add to playlist">＋</button>' +
    (extraButton || '') +
  '</div>';
}

// ---------- "Add to playlist" popup ----------
function openAddDialog(songId) {
  playlists = load("playlists", []);
  var dlg = document.getElementById("dlg");
  var html = '<h3>Add to playlist</h3>';
  if (playlists.length === 0) html += '<p>No playlists yet. Create one below.</p>';
  playlists.forEach(function (p, i) {
    html += '<button data-pick="' + i + '">' + esc(p.name) + '</button>';
  });
  html += '<input type="text" id="newPl" placeholder="New playlist name">' +
          '<button id="createPl">Create &amp; add</button>' +
          '<button class="small" id="closeDlg">Cancel</button>';
  dlg.innerHTML = html;
  dlg.showModal();

  dlg.onclick = function (e) {
    var t = e.target;
    if (t.getAttribute("data-pick") !== null) {
      var p = playlists[Number(t.getAttribute("data-pick"))];
      if (p.songs.indexOf(songId) === -1) p.songs.push(songId);
      save("playlists", playlists);
      dlg.close();
      window.dispatchEvent(new Event("playlistchange"));
    }
    if (t.id === "createPl") {
      var name = document.getElementById("newPl").value.trim();
      if (name === "") return;
      playlists.push({ name: name, songs: [songId] });
      save("playlists", playlists);
      dlg.close();
      window.dispatchEvent(new Event("playlistchange"));
    }
    if (t.id === "closeDlg") dlg.close();
  };
}

// ---------- One click handler for all buttons with data-play / data-like / data-add ----------
document.addEventListener("click", function (e) {
  var t = e.target.closest("button");
  if (!t) return;
  if (t.getAttribute("data-play") !== null) {
    var id = Number(t.getAttribute("data-play"));
    if (id === currentId && !audio.paused) audio.pause();
    else if (id === currentId) audio.play();
    else loadSong(id, true);
  }
  if (t.getAttribute("data-like") !== null) toggleLike(Number(t.getAttribute("data-like")));
  if (t.getAttribute("data-add") !== null) openAddDialog(Number(t.getAttribute("data-add")));
});

// ---------- Start everything when the page loads ----------
buildNav();
buildPlayer();
document.body.insertAdjacentHTML("beforeend", '<dialog id="dlg"></dialog>');
loadSong(currentId, false);
