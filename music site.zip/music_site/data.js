// ===== Song data (all songs are listed here) =====
var SONGS = [
  { id: 1, title: "Sunrise Walk",   artist: "Luna Waves",  album: "Morning Light", genre: "Chill",      file: "songs/song1.wav", emoji: "🌅", color: "#f59e0b" },
  { id: 2, title: "Midnight Rain",  artist: "Luna Waves",  album: "Morning Light", genre: "Chill",      file: "songs/song2.wav", emoji: "🌧️", color: "#6366f1" },
  { id: 3, title: "Neon Streets",   artist: "Pixel Pulse", album: "Digital Dreams", genre: "Electronic", file: "songs/song3.wav", emoji: "🌃", color: "#ec4899" },
  { id: 4, title: "Fast Forward",   artist: "Pixel Pulse", album: "Digital Dreams", genre: "Electronic", file: "songs/song4.wav", emoji: "⚡", color: "#06b6d4" },
  { id: 5, title: "Quiet Hours",    artist: "Luna Waves",  album: "Night Notes",   genre: "Chill",      file: "songs/song5.wav", emoji: "🌙", color: "#8b5cf6" },
  { id: 6, title: "Happy Days",     artist: "Pixel Pulse", album: "Night Notes",   genre: "Pop",        file: "songs/song6.wav", emoji: "😄", color: "#10b981" }
];

// Artist info (used on the Album/Artist page)
var ARTISTS = {
  "Luna Waves":  "Luna Waves makes soft, relaxing tunes that are perfect for studying or sleeping.",
  "Pixel Pulse": "Pixel Pulse creates energetic electronic and pop beats inspired by video games."
};
